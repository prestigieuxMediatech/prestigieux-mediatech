"use client";

import { useParams, useRouter } from "next/navigation";
import Navbar from "../../components/Navbar";
import Footer from "../../components/Footer";
import styles from "../../styles/ServiceDetail.module.css";

export default function ServiceDetailPage() {
  const router = useRouter();
  const params = useParams();
  const slug = params?.slug;

  if (!slug) {
    return (
      <>
        <Navbar />
        <div style={{padding: '2rem', textAlign: 'center'}}>
          Loading...
        </div>
        <Footer />
      </>
    );
  }

  const goBack = () => router.push("/services");

  const openFunnel = () => {
    const overlay = document.getElementById('funnelOverlay');
    if (overlay) overlay.style.display = 'block';
  };

  if (slug === 'svc-web') {
    return (
      <>
        <Navbar />
        <div className={styles['page-view']}>
          {/* Hero */}
          <div className={styles.section}>
            <div className={styles['section-inner']}>
              <button onClick={goBack} style={{
                marginBottom: '1rem',
                padding: '0.5rem 1rem',
                border: '1px solid var(--line2)',
                background: 'none',
                color: 'var(--text)',
                borderRadius: '4px',
                cursor: 'pointer'
              }}>
                ← All Services
              </button>
              <div className={styles.tag}>Most Popular</div>
              <h1 className={styles['section-title']}>Website Development</h1>
              <p style={{fontSize: '1.1rem', color: 'var(--muted)', maxWidth: '600px', lineHeight: '1.7'}}>
                Fast, SEO-ready sites that convert visitors into clients. Built for speed, mobile, and growth.
              </p>
              <div style={{marginTop: '2rem'}}>
                <button className={styles['btn-primary']} onClick={openFunnel}>
                  Get Custom Quote
                </button>
              </div>
            </div>
          </div>

          {/* Features */}
          <div className={styles.section}>
            <div className={styles['section-inner']}>
              <div className={styles.tag}>What You Get</div>
              <h2 className={styles['section-title']}>Everything Included</h2>
              <div className={styles['features-grid']}>
                <div className={styles['feature-card']}>
                  <h4>🔥 Custom Design</h4>
                  <p>Pixel-perfect UI/UX designed for your brand identity.</p>
                </div>
                <div className={styles['feature-card']}>
                  <h4>⚡ SEO Optimized</h4>
                  <p>Google-first architecture with Core Web Vitals excellence.</p>
                </div>
                <div className={styles['feature-card']}>
                  <h4>📱 Mobile-First</h4>
                  <p>Perfect on all devices with lightning fast performance.</p>
                </div>
                <div className={styles['feature-card']}>
                  <h4>✨ CMS Ready</h4>
                  <p>Easy content management without coding knowledge.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Pricing */}
          <div className={styles.section}>
            <div className={styles['section-inner']}>
              <div className={styles.tag}>Pricing</div>
              <h2 className={styles['section-title']}>Simple Transparent Pricing</h2>
              <div className={styles['pricing-grid']}>
                <div className={styles['price-card']}>
                  <div className={styles['price-tier']}>Starter</div>
                  <div className={styles['price-name']}>Landing Page</div>
                  <div className={styles['price-tag']}>&dollar;1,990</div>
                  <div className={styles['price-note']}>One time</div>
                </div>
                <div className={styles['price-card featured']}>
                  <div className={styles['price-tier']}>Pro</div>
                  <div className={styles['price-name']}>Full Website</div>
                  <div className={styles['price-tag']}>&dollar;4,990</div>
                  <div className={styles['price-note']}>One time</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <Navbar />
      <div className={styles['page-view']}>
        <div className={styles.section}>
          <div className={styles['section-inner']}>
            <h1>Service Not Found</h1>
            <p>Go back to <button onClick={goBack} style={{color: 'var(--gold)', background: 'none', border: 'none', fontSize: 'inherit'}}>Services</button></p>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}

