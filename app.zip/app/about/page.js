import Footer from "../components/Footer";
import HeroAbout from "../components/HeroAbout";
import Navbar from "../components/Navbar";

export default function About() {
  return (
    <>
      <Navbar />
      <HeroAbout />
      <Footer />
    
    </>
  );
}
