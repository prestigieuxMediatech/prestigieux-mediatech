"use client";

import styles from "../styles/Contact.module.css";
import { FaPhoneAlt, FaEnvelope, FaWhatsapp, FaClock } from "react-icons/fa";



export default function Contact() {

  const submitContact = async (e) => {
    e.preventDefault();

    const form = e.target;

    const data = {
      name: form.name.value,
      email: form.email.value,
      phone: form.phone.value,
      service: form.service.value,
      message: form.message.value,
    };

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(data),
      });

      if (res.ok) {
        alert("Message sent successfully!");
        form.reset();
      } else {
        alert("Something went wrong!");
      }
    } catch (error) {
      console.error(error);
      alert("Server error!");
    }
  };

  return (
    <div id="page-contact" className={styles.pageView}>

      {/* HERO */}
      <div className={styles.pageHero}>
        <div className={styles.pageHeroInner}>
          <div className={styles.tag}>Get In Touch</div>

          <h1>
            Let's Grow Your<br />
            Brand Together
          </h1>

          <p className={styles.phSub}>
            We reply within 2 hours during business hours — 8 AM to 10 PM, 7 days a week.
          </p>
        </div>
      </div>

      {/* SECTION */}
      <div className={styles.section}>
        <div className={styles.sectionInner}>

          <div className={styles.contactGrid}>

            {/* FORM */}
            <form className={styles.form} onSubmit={submitContact}>

              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Your Name *</label>
                <input name="name" className={styles.formCtrl} type="text" required />
              </div>

              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Email Address</label>
                <input name="email" className={styles.formCtrl} type="email" />
              </div>

              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Phone / WhatsApp *</label>
                <input name="phone" className={styles.formCtrl} type="tel" required />
              </div>

              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Service Interested In</label>

                <select name="service" className={styles.formCtrl}>
                  <option value="">Select a service</option>
                  <option>Website Development</option>
                  <option>Mobile App Development</option>
                  <option>Performance Marketing</option>
                  <option>Lead Generation</option>
                  <option>Content Creation</option>
                  <option>SEO & Digital Marketing</option>
                  <option>Brand Identity</option>
                  <option>UI/UX Design</option>
                  <option>Virtual Assistant</option>
                  <option>Full Package</option>
                </select>
              </div>

              <div className={styles.formGroup}>
                <label className={styles.formLabel}>Your Message *</label>
                <textarea
                  name="message"
                  className={styles.formCtrl}
                  required
                />
              </div>

              <button className={styles.btnPrimary} type="submit">
                Send Message →
              </button>

            </form>

            {/* INFO */}
            <div className={styles.contactInfo}>

              <div className={styles.infoItem}>
                <div className={styles.icon}>
                  <FaPhoneAlt />
                </div>
                <div>
                  <div className={styles.infoLabel}>Phone</div>
                  <div className={styles.infoValue}>
                    <a href="tel:+919987952982">+91 9987952982</a><br />
                    <a href="tel:+919136892346">+91 9136892346</a>
                  </div>
                </div>
              </div>

              <div className={styles.infoItem}>
                <div className={styles.icon}>
                  <FaEnvelope />
                </div>
                <div>
                  <div className={styles.infoLabel}>Email</div>
                  <div className={styles.infoValue}>
                    <a href="mailto:info@prestigieux.in">
                      info@prestigieux.in
                    </a>
                  </div>
                </div>
              </div>

              <div className={styles.infoItem}>
                <div className={styles.icon}>
                  <FaWhatsapp />
                </div>
                <div>
                  <div className={styles.infoLabel}>WhatsApp</div>
                  <div className={styles.infoValue}>
                    <a
                      href="https://wa.me/919987952982"
                      target="_blank"
                      rel="noreferrer"
                    >
                      Chat with us on WhatsApp →
                    </a>
                  </div>
                </div>
              </div>

              <div className={styles.infoItem}>
                <div className={styles.icon}>
                  <FaClock />
                </div>
                <div>
                  <div className={styles.infoLabel}>Business Hours</div>
                  <div className={styles.infoValue}>
                    8:00 AM – 10:00 PM<br />
                    Monday to Sunday
                  </div>
                </div>
              </div>

              <div className={styles.actions}>
               <a className={styles.btnPrimary} href="https://wa.me/919987952982">
                     WhatsApp Us Now
                <FaWhatsapp />
                </a>

               <a className={styles.btnGhost} href="tel:+919987952982">
  Call Now 
 <span> <FaPhoneAlt />+91 9987952982</span>
</a>

              </div>

            </div>

          </div>

        </div>
      </div>
    </div>
  );
}
