'use client'

import { useState, useEffect } from "react";
import styles from "../styles/Funnel.module.css";

import {
  FaBullseye,
  FaBullhorn,
  FaRocket,
  FaMobileAlt,
  FaChartLine,
  FaGlobe,
  FaCheckCircle
} from "react-icons/fa";

export default function Funnel() {

  const [fStep, setFStep] = useState(1);
  const [fSvcs, setFSvcs] = useState([]);
  const [fBudget, setFBudget] = useState('');
  const [fGoal, setFGoal] = useState('');
  const [isOpen, setIsOpen] = useState(false);

  const [loading, setLoading] = useState(false);
  const [showStrategy, setShowStrategy] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const [userName, setUserName] = useState('');
  const [waLink, setWaLink] = useState('');

  const fTitles = [
    "What can we help you with?",
    "What is your budget?",
    "What is your primary goal?",
    "Get your free strategy"
  ];

  const fSubs = [
    "Select all that apply — we'll build a custom plan",
    "We'll tailor the best plan for you",
    "We'll build your strategy around this",
    "Personalised plan sent instantly"
  ];

  const services = [
    "Performance Marketing",
    "Lead Generation",
    "Content Creation",
    "Website Development",
    "Mobile App",
    "SEO & Digital Marketing",
    "Brand Identity",
    "UI/UX Design",
    "Virtual Assistant"
  ];

  const serviceSubs = [
    "Meta · LinkedIn · YouTube Ads",
    "B2B & B2C qualified leads daily",
    "Reels, blogs, ad creatives",
    "Fast, SEO-ready, converts visitors",
    "Android & IOS, from ₹40K",
    "Rank #1, grow organic traffic",
    "Logo, colours, brand system",
    "Figma prototypes, design systems",
    "Admin, ops, customer support"
  ];

  const budgets = [
    "Under ₹15K",
    "₹15K–30K",
    "₹30K–60K",
    "₹60K–1.5L",
    "₹1.5L–5L",
    "₹5L+"
  ];

  const budgetLabels = [
    "Micro Budget",
    "Starter",
    "Growth",
    "Scale",
    "Enterprise",
    "Unlimited"
  ];

  const goals = [
    "Generate More Leads",
    "Build Brand Awareness",
    "Launch New Business",
    "Grow Social Media",
    "Better Website or App",
    "Scale Revenue"
  ];

  // ✅ AUTO OPEN
  useEffect(() => {
    const t = setTimeout(() => {
      setIsOpen(true);
      document.body.style.overflow = 'hidden';
    }, 1200);
    return () => clearTimeout(t);
  }, []);

  const openFunnel = () => {
    setIsOpen(true);
    document.body.style.overflow = 'hidden';
  };

  const closeFunnel = () => {
    setIsOpen(false);
    document.body.style.overflow = '';
  };

  const toggleSvc = (svc) => {
    setFSvcs(prev =>
      prev.includes(svc)
        ? prev.filter(s => s !== svc)
        : [...prev, svc]
    );
  };

  // ✅ FINAL FLOW FIXED
  const submitLead = () => {
    const name = document.getElementById('fName').value.trim();
    const phone = document.getElementById('fPhone').value.trim();
    const email = document.getElementById('fEmail').value.trim();
    const brand = document.getElementById('fBrand').value.trim();

    if (!name || !phone) {
      alert('Please enter your name and phone number.');
      return;
    }

    setUserName(name);
    setLoading(true);

    const waMsg = encodeURIComponent(
      '🔥 NEW LEAD\n\n' +
      'Name: ' + name + '\n' +
      'Phone: ' + phone + '\n' +
      'Email: ' + email + '\n' +
      'Brand: ' + brand + '\n\n' +
      'Services: ' + fSvcs.join(', ') + '\n' +
      'Budget: ' + fBudget + '\n' +
      'Goal: ' + fGoal
    );

    const link = `https://wa.me/919987952982?text=${waMsg}`;
    setWaLink(link);

    setTimeout(() => {
      setLoading(false);
      setShowStrategy(true);

      setTimeout(() => {
        setShowStrategy(false);
        setShowSuccess(true);
      }, 2000);

    }, 1200);
  };

  return (
    <>
      {isOpen && (
        <div
          id="funnelOverlay"
          className={`${styles['funnel-overlay']} ${styles.open}`}
          onClick={(e) => e.target.id === "funnelOverlay" && closeFunnel()}
        >
          <div className={styles['funnel-box']}>

            <button
              className={styles['funnel-close-btn']}
              onClick={closeFunnel}
            >
              ✕
            </button>

            {!showSuccess && (
              <>
               <h3 className={styles.funnelTitle}>
  {fTitles[fStep - 1]}
</h3>

<p className={styles.funnelSub}>
  {fSubs[fStep - 1]}
</p>

              </>
            )}

            {/* STEP 1 */}
            {fStep === 1 && !showSuccess && (
              <div className={`${styles['funnel-step']} ${styles.active}`}>
                <div className={styles['funnel-options']}>

                  {services.map((svc, i) => (
                    <div
                      key={i}
                      className={`${styles['funnel-opt']} ${fSvcs.includes(svc) ? styles.selected : ''}`}
                      onClick={() => toggleSvc(svc)}
                    >
                      <div className={styles['funnel-opt-index']}>
                        {(i + 1).toString().padStart(2, '0')}
                      </div>

                      <div className={styles['funnel-opt-text']}>
                        <div className={styles['funnel-opt-name']}>{svc}</div>
                        <div className={styles['funnel-opt-sub']}>{serviceSubs[i]}</div>
                      </div>

                      <span className={styles['funnel-check']}>
                        <FaCheckCircle />
                      </span>
                    </div>
                  ))}

                </div>

                <div style={{ marginTop: '1rem' }}>
                  <button
                    className={styles['funnel-btn']}
                    disabled={!fSvcs.length}
                    onClick={() => setFStep(2)}
                  >
                    Next →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2 */}
            {fStep === 2 && !showSuccess && (
              <div className={`${styles['funnel-step']} ${styles.active}`}>
                <div className={styles['budget-grid']}>

                  {budgets.map((b, i) => (
                    <div
                      key={i}
                      className={`${styles['budget-opt']} ${fBudget === b ? styles.selected : ''}`}
                      onClick={() => setFBudget(b)}
                    >
                      <span className={styles['budget-amt']}>{b}</span>
                      <span className={styles['budget-label']}>{budgetLabels[i]}</span>
                    </div>
                  ))}

                </div>

                <div className={styles['funnel-nav']}>
                  <button
                    className={styles['funnel-back-btn']}
                    onClick={() => setFStep(1)}
                  >
                    ← Back
                  </button>

                  <button
                    className={styles['funnel-btn']}
                    disabled={!fBudget}
                    onClick={() => setFStep(3)}
                  >
                    Next →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3 */}
            {fStep === 3 && !showSuccess && (
              <div className={`${styles['funnel-step']} ${styles.active}`}>
                <div className={styles['goal-grid']}>

                  {goals.map((g, i) => {
                    const icons = [
                      <FaBullseye />,
                      <FaBullhorn />,
                      <FaRocket />,
                      <FaMobileAlt />,
                      <FaGlobe />,
                      <FaChartLine />
                    ];

                    return (
                      <div
                        key={i}
                        className={`${styles['goal-opt']} ${fGoal === g ? styles.selected : ''}`}
                        onClick={() => setFGoal(g)}
                      >
                        <span>{icons[i]}</span>
                        {g}
                      </div>
                    );
                  })}

                </div>

                <div className={styles['funnel-nav']}>
                  <button
                    className={styles['funnel-back-btn']}
                    onClick={() => setFStep(2)}
                  >
                    ← Back
                  </button>

                  <button
                    className={styles['funnel-btn']}
                    disabled={!fGoal}
                    onClick={() => setFStep(4)}
                  >
                    Next →
                  </button>
                </div>
              </div>
            )}

            {/* STEP 4 */}
            {fStep === 4 && !showSuccess && (
              <div className={`${styles['funnel-step']} ${styles.active}`}>

                <div className={styles['funnel-form-fields']}>
                  <input className={styles['funnel-input']} id="fName" placeholder="Your Name *" />
                  <input className={styles['funnel-input']} id="fPhone" placeholder="WhatsApp / Phone *" />
                  <input className={styles['funnel-input']} id="fEmail" placeholder="Email Address" />
                  <input className={styles['funnel-input']} id="fBrand" placeholder="Brand / Business Name" />
                  <textarea className={styles['funnel-input']} id="fMsg" placeholder="Any specific requirements?" />
                </div>

                {loading && (
                  <div className={`${styles['funnel-spinner']} ${styles.show}`}>
                    <div className={styles.spinner}></div>
                    <p style={{ color: 'var(--muted)', fontSize: '.82rem' }}>
                      Building your custom growth strategy…
                    </p>
                  </div>
                )}

              {showStrategy && (
  <div className={`${styles['funnel-strategy']} ${styles.show}`}>
Get Your Free Strategy

🎯 {fSvcs[0] || 'Marketing'} campaign targeting {fGoal}

📈 Multi-channel funnel to reduce CAC by 40%

💬 WhatsApp + email automation to convert leads 24/7
  </div>
)}

                {!loading && !showStrategy && (
                  <div className={styles['funnel-nav']}>
                    <button
                      className={styles['funnel-back-btn']}
                      onClick={() => setFStep(3)}
                    >
                      ← Back
                    </button>

                    <button
                      className={styles['funnel-btn']}
                      onClick={submitLead}
                    >
                      Get My Free Strategy
                    </button>
                  </div>
                )}
              </div>
            )}

            {/* SUCCESS */}
            {showSuccess && (
              <div className={styles['funnel-success']} style={{ display: "block" }}>

                <div className={styles['funnel-success-icon']}>🎉</div>

                <h3>Strategy sent, {userName}!</h3>

                <p>
                  Check your WhatsApp. Our team will call you within 2 hours.
                </p>

                <div className={styles['funnel-cta-row']}>
                  <a href={waLink} target="_blank" className={styles['funnel-btn']}>
                    WhatsApp Now
                  </a>

                  <button
                    onClick={closeFunnel}
                    className={styles['funnel-back-btn']}
                  >
                    Close
                  </button>
                </div>
              </div>
            )}

          </div>
        </div>
      )}

      {/* FLOAT BUTTON */}
      <button
        id="stratBadge"
        onClick={openFunnel}
        className={styles['strategy-badge']}
      >
        <svg width="16" height="16">
          <use href="#ic-target" />
        </svg>
        Free Strategy
      </button>
    </>
  );
}
