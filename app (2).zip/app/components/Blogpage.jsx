"use client";

import Link from "next/link";
import styles from "../styles/BlogPage.module.css";

export default function Blogpage() {

  const projects = [
    {
      slug: "best-digital-marketing-agency-2026",
      category: "marketing",
      title: "How to Choose the Best Digital Marketing Agency in 2026",
      description:
        "Step-by-step breakdown of how ad delivery system optimizes conversions.",
      tag: "Marketing",
      image: "/blog-hero.png",
    },
    {
      slug: "fast-website-importance",
      category: "web",
      title: "Why Every Business Needs a Fast Website",
      description:
        "Speed impacts SEO, conversions and user trust more than you think.",
      tag: "Development",
      image:
        "https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=260&fit=crop",
    },
  ];

  return (
    <div id="page-blog" className={styles["page-view"]}>

      {/* HERO */}
      <div className={styles["page-hero"]}>
        <div className={styles["page-hero-inner"]}>
          <div className={styles.tag}>Insights & Updates</div>

          <h1>
            Our Blogs:<br />
            Insights, Strategy & Trends
          </h1>

          <p className={styles["ph-sub"]}>
            Latest insights on marketing, development, AI and branding strategies.
          </p>
        </div>
      </div>

      {/* GRID */}
      <div className={styles["portfolio-grid"]}>
        {projects.map((post, index) => (
          <Link key={index} href={`/blog/${post.slug}`}>
            <div className={styles["port-card"]}>

              <div className={styles["port-thumb"]}>
                <img src={post.image} alt={post.title} />
              </div>

              <div className={styles["port-info"]}>
                <h4>{post.title}</h4>
                <p>{post.description}</p>
                <span className={styles["port-tag"]}>{post.tag}</span>
              </div>

            </div>
          </Link>
        ))}
      </div>

    </div>
  );
}
